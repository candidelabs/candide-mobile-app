
███╗░░░███╗░█████╗░░██████╗░██╗░█████╗░
████╗░████║██╔══██╗██╔════╝░██║██╔══██╗
██╔████╔██║███████║██║░░██╗░██║██║░░╚═╝
██║╚██╔╝██║██╔══██║██║░░╚██╗██║██║░░██╗
██║░╚═╝░██║██║░░██║╚██████╔╝██║╚█████╔╝
╚═╝░░░░░╚═╝╚═╝░░╚═╝░╚═════╝░╚═╝░╚════╝░


~GUIDELINES~

Please do:

- Use enough space around the logo.
- Use the vector version (.svg) if possible.


Please do not:

- Edit the original files.
- Use parts of these files for your own company’s or product’s use.
- Use these logos to imply a partnership or endorsement by Magic without formal approval.


Questions? Contact hello@magic.link


~ Magic Team 🎩